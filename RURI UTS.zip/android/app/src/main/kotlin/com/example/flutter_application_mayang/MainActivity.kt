package com.example.flutter_application_mayang

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
